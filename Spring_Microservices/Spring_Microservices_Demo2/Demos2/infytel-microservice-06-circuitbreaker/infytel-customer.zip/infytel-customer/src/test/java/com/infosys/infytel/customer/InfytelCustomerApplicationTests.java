package com.infosys.infytel.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InfytelCustomerApplicationTests {

	@Test
	void contextLoads() {
	}

}
