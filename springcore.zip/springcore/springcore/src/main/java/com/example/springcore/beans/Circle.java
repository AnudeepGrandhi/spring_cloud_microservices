package com.example.springcore.beans;

public class Circle implements Shape {
	
	public Circle() {
		super();
		// TODO Auto-generated constructor stub
		System.out.println("Circle Instantiated");
	}

	public void drawShape() {
		// TODO Auto-generated method stub
		System.out.println("Circle Drawn");
	}

}
