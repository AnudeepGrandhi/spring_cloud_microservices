package com.example.springcore.beans;

public interface Shape {

	void drawShape();
}
